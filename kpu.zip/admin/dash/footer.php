</div>
 <!-- CoreUI and necessary plugins-->
    <script src="asset/vendors/@coreui/coreui/js/coreui.bundle.min.js"></script>
    <script src="asset/vendors/simplebar/js/simplebar.min.js"></script>
    <!-- Plugins and scripts required by this view-->
    <script src="asset/vendors/chart.js/js/chart.min.js"></script>
    <script src="asset/vendors/@coreui/chartjs/js/coreui-chartjs.js"></script>
    <script src="asset/vendors/@coreui/utils/js/coreui-utils.js"></script>
    <script src="asset/js/main.js"></script>
    <script>
    </script>

  </body>
</html>